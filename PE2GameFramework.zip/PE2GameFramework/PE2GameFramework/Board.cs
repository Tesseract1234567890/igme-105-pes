﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE2GameFramework
{
    internal class Board
    {
        private int spaceBetweenBases;
        private int maxPlayerPieces;
        private Player[] players;
    }
}
